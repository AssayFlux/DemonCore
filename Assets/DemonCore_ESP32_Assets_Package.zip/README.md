# ESP32 NodeMCU-32S Professional Reconstruction

## Reference basis
This reconstruction was created from the two user-supplied photographs (front and rear). The front photo clearly shows the RF shield/antenna, purple capacitor, AMS1117 regulator, CP2102, EN/IO0 switches and USB connector. The rear photo shows the light printed region, NodeMCU / ESP-32S branding and GPIO silkscreen.

## Coordinate system and dimensions
- X: board width; Y: board length; Z: thickness. Antenna at +Y; USB connector at -Y.
- PCB: 25 × 55 × 1.6 mm (user-provided provisional dimensions).
- GPIO: 19 positions per side, 2.54 mm pitch; modelled outward blade extension 4 mm and 0.64 mm metal thickness.
- All component positions and most component dimensions are estimates from perspective photographs, not caliper measurements or manufacturer drawings.

## Important photographic discrepancy
The photographs show conventional round through-hole header pins protruding above the board plane. The requested acceptance specification explicitly requires 38 sideways outward-facing, bent contacts. The CAD follows that explicit geometry requirement rather than copying the visible round-pin shape. Confirm whether this is intentional before using the model for fabrication.

## Files
- `ESP32_NodeMCU_Professional.scad`: editable, parameterized OpenSCAD source with modular components and show/hide controls.
- `ESP32_NodeMCU_Professional.stl`: assembled geometry (uncoloured).
- Component STL files: separately exported geometry groups.
- `ESP32_NodeMCU_Professional.3mf`: attempted colour-aware scene export when supported by the installed mesh backend.
- `Preview_*.png`: generated views of the reconstructed geometry.
- `VALIDATION_REPORT.md`: actual checks and limitations.

## Export instructions
Open the SCAD file in OpenSCAD. Set `part` to `all`, `pcb`, `rf`, `usb`, `gpio`, `power`, `cp2102`, or `buttons`. Adjust the parameter block at the beginning. Press F6 for a CGAL render, then File → Export → Export as STL. Colours in OpenSCAD preview do not survive ordinary STL export. Use the 3MF only after confirming your slicer imports its separate object/material colours correctly.

## Printing recommendations
This is a visual/educational reconstruction, not an electrically functional replacement board. Print the PCB body flat with supports disabled where possible. Use 0.12–0.20 mm layers for detailed display parts. For multi-material output, use the 3MF if your slicer confirms material assignment; otherwise print component groups separately. Metallic and gold finishes require filament/material choice or post-processing. Do not solder or install these printed contacts as electrical connectors.

## Assembly coordinates
All components use the same origin at the PCB centre. PCB top surface is Z=1.6 mm; the antenna is at +Y and USB-C at -Y. Component STL groups retain their assembled coordinates and can be imported as aligned parts.

## Known limitations
- No physical caliper measurements, scale reference, or exact board revision number were supplied.
- Some rear artwork is approximated; fine silkscreen text and tiny vias are not a pixel-perfect trace.
- USB-C is a hollow shell approximation with visible tongue and contacts, not a certified connector mechanical drawing.
- The OpenSCAD source is the editable master; generated STL groups are polygon meshes.
