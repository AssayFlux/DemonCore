/*
 ESP32 NodeMCU-32S photograph-referenced reconstruction
 Units: millimetres. Coordinate system: X=width, Y=length (antenna +Y,
 USB-C -Y), Z=thickness. Dimensions are provisional unless stated otherwise.
 Set part to "all", "pcb", "rf", "usb", "gpio", "power", "cp2102", "buttons".
*/
// ---------------- USER PARAMETERS ----------------
pcb_w = 25; pcb_l = 55; pcb_t = 1.6; corner_r = 1.6;
gpio_pitch = 2.54; gpio_count = 19; gpio_metal_t = 0.64; gpio_extension = 4;
show_front_components = true; show_rear_graphics = true;
show_copper = true; show_gpio_contacts = true; show_gpio_labels = true;
show_usb_internals = true; fine_details = true;
detail_level = 1; // 0 = fast preview, 1 = normal, 2 = fine
$fn = detail_level >= 2 ? 36 : (detail_level == 1 ? 20 : 12);
part = "all";

// Palette
pcb_blue = [0.055,0.16,0.38]; pcb_edge = [0.018,0.045,0.13];
silver = [0.78,0.82,0.86]; bright_silver = [0.92,0.94,0.96];
gold = [0.83,0.60,0.20]; copper = [0.72,0.34,0.16]; ivory = [0.94,0.92,0.82];
graphite = [0.075,0.085,0.10]; purple = [0.31,0.16,0.39]; beige = [0.72,0.65,0.50];
green = [0.05,0.55,0.22]; blue_led = [0.10,0.35,0.82]; black = [0.012,0.016,0.022];

// Component positions inferred from front photograph; estimated, not manufacturer drawings.
rf_x=0; rf_y=11.2; rf_w=17.0; rf_l=27.0; rf_z=2.05; rf_h=1.45;
antenna_y=25.0; usb_y=-28.5;

module rounded_box(x,y,z,r) {
  hull() for (sx=[-1,1], sy=[-1,1]) translate([sx*(x/2-r),sy*(y/2-r),0]) cylinder(r=r,h=z,center=true);
}
module pcb_body(){ color(pcb_blue) translate([0,0,pcb_t/2]) rounded_box(pcb_w,pcb_l,pcb_t,corner_r); }
module pcb_edges(){ color(pcb_edge) translate([0,0,pcb_t/2]) difference(){ rounded_box(pcb_w,pcb_l,pcb_t,corner_r); translate([0,0,0.12]) rounded_box(pcb_w-0.35,pcb_l-0.35,pcb_t,corner_r); } }
module via(x,y,r=0.38){ translate([x,y,pcb_t+0.015]) color([0.10,0.12,0.15]) cylinder(r=r,h=0.04); translate([x,y,pcb_t+0.04]) color(gold) difference(){ cylinder(r=r,h=0.035); cylinder(r=r*0.48,h=0.04); } }
module pcb_vias(){ for(x=[-9:3:9],y=[-23:4:23]) via(x,y,0.23); for(p=[[ -8,-7],[8,-7],[-8,4],[8,4],[-7,22],[7,22]]) via(p[0],p[1],0.32); }
module trace2d(points,w=0.22){ for(i=[0:len(points)-2]) hull(){ translate([points[i][0],points[i][1],0]) cylinder(d=w,h=0.035); translate([points[i+1][0],points[i+1][1],0]) cylinder(d=w,h=0.035); } }
module copper_traces_front(){ color(copper) translate([0,0,pcb_t+0.02]) { trace2d([[-9,-8],[-7,-6],[-5,-6],[-3,-4]],0.22); trace2d([[8,-7],[6,-5],[4,-5],[2,-3]],0.22); trace2d([[-8,1],[-6,3],[-3,3]],0.18); trace2d([[8,0],[6,2],[3,2]],0.18); } }
module copper_traces_back(){ color(copper) translate([0,0,-0.04]) { trace2d([[-9,-18],[-7,-16],[-4,-16]],0.18); trace2d([[9,-18],[7,-16],[4,-16]],0.18); trace2d([[-8,18],[-6,16],[-3,16]],0.18); } }
module solder_pads(){ color([0.72,0.72,0.70]) for(x=[-10.2,10.2], y=[-22:gpio_pitch:22]) translate([x,y,pcb_t+0.04]) rounded_box(1.0,0.85,0.12,0.18); }

module raised_text(txt,size=0.85,rot=0,z=pcb_t+0.035){ color(ivory) translate([0,0,z]) rotate([0,0,rot]) linear_extrude(0.035) text(txt,size=size,halign="center",valign="center",font="Liberation Sans:style=Bold"); }
module antenna_pattern(){ color(black) translate([0,antenna_y,pcb_t+0.15]) { rounded_box(17,5.6,0.3,0.8); for(x=[-6:3:6]) translate([x,0,0.17]) cube([1.1,3.3,0.08],center=true); for(x=[-4.5:3:4.5]) translate([x,1.7,0.17]) cube([1.1,1.1,0.08],center=true); } }
module esp32_antenna(){ antenna_pattern(); }
module esp32_castellations(){ color(gold) for(s=[-1,1],i=[0:9]) translate([s*8.75,-1.5+i*2.55,pcb_t+0.08]) rounded_box(0.65,1.05,0.16,0.16); }
module esp32_rf_shield(){
 color([0.68,0.70,0.72]) translate([rf_x,rf_y,rf_z]) rounded_box(rf_w,rf_l,rf_h,1.1);
 color([0.88,0.89,0.90]) translate([0,rf_y,rf_z+rf_h/2+0.025]) difference(){ rounded_box(rf_w-0.25,rf_l-0.25,0.05,1.0); }
 color(ivory) translate([0,rf_y,rf_z+rf_h/2+0.06]) linear_extrude(0.025) { text("WiFi ESP-32",size=2.15,halign="center",valign="center",font="Liberation Sans:style=Bold"); }
 color(ivory) translate([0,rf_y-5.1,rf_z+rf_h/2+0.06]) linear_extrude(0.025) text("WiFi + BT SoC Inside",size=1.12,halign="center",valign="center");
 color(ivory) translate([0,rf_y-8.2,rf_z+rf_h/2+0.06]) linear_extrude(0.025) text("ISM 2.4G 802.11 b/g/n",size=0.92,halign="center",valign="center");
 color(black) translate([-6.0,rf_y-10.5,rf_z+rf_h/2+0.08]) cylinder(r=0.48,h=0.04);
}

// L-shaped spring contact: embedded vertical anchor plus flat horizontal outward leg.
module gpio_contact_left(y){
 color(gold) union(){
  // Vertical anchor is buried into the PCB edge; outward leg is coplanar with board.
  translate([-11.9,y,0.8]) rounded_box(0.85,0.64,2.4,0.12);
  translate([-14.35,y,0.8]) rounded_box(4.55,0.64,0.64,0.12);
  translate([-16.58,y,0.8]) sphere(r=0.31);
 }
}
module gpio_contact_right(y){ mirror([1,0,0]) gpio_contact_left(y); }
module gpio_contacts(){ for(i=[0:gpio_count-1]) { y= (gpio_count-1)*gpio_pitch/2-i*gpio_pitch; gpio_contact_left(y); gpio_contact_right(y); } }

rowA=["CLK","SD0","SD1","P15","P2","P0","P4","P16","P17","P5","P18","P19","GND","P21","RX","TX","P22","P23","GND"];
rowB=["3V3","EN","SVP","SVN","P34","P35","P32","P33","P25","P26","P27","P14","P12","GND","P13","SD2","SD3","CMD","5V"];
module gpio_labels_back(){
 // Rear observer sees X mirrored; row A is on viewer-left, therefore +X in model coordinates.
 for(i=[0:18]) { y=9*gpio_pitch-i*gpio_pitch;
  color(ivory) translate([8.35,y,-0.045]) rotate([180,0,180]) linear_extrude(0.035) text(rowA[i],size=0.78,halign="center",valign="center",font="Liberation Sans:style=Bold");
  color(ivory) translate([-8.35,y,-0.045]) rotate([180,0,180]) linear_extrude(0.035) text(rowB[i],size=0.78,halign="center",valign="center",font="Liberation Sans:style=Bold");
 }
}
module rear_silkscreen(){
 if(show_rear_graphics){
  color([0.93,0.94,0.90]) translate([0,1.0,-0.055]) rounded_box(18.8,30.0,0.045,0.8);
  color(black) translate([0,16,-0.09]) rounded_box(15.8,11.5,0.05,1.1);
  color(ivory) translate([0,16,-0.13]) linear_extrude(0.04) text("◉",size=5,halign="center",valign="center");
  color(graphite) translate([0,7,-0.09]) rotate([180,0,90]) linear_extrude(0.04) text("NODEMCU",size=2.6,halign="center",valign="center",font="Liberation Sans:style=Bold");
  color(graphite) translate([0,-1,-0.09]) rotate([180,0,90]) linear_extrude(0.04) text("ESP-32S",size=2.7,halign="center",valign="center",font="Liberation Sans:style=Bold");
  color(graphite) translate([0,-7,-0.09]) rotate([180,0,90]) linear_extrude(0.04) text("V1.1  101010",size=1.1,halign="center",valign="center");
 }
}

module smd(x,y,w,l,h,c=graphite){ color(c) translate([x,y,pcb_t+h/2]) rounded_box(w,l,h,min(w,l)*0.16); }
module capacitor(x,y){ smd(x,y,2.4,3.1,1.9,purple); color([0.45,0.40,0.42]) translate([x,y,pcb_t+1.95]) linear_extrude(0.03) text("100",size=0.75,halign="center",valign="center"); }
module resistor(x,y){ smd(x,y,1.0,1.65,0.65,beige); color(silver) for(s=[-1,1]) translate([x,y+s*0.72,pcb_t+0.37]) cube([1.0,0.22,0.28],center=true); }
module ams1117_regulator(){ smd(2.9, -3.3, 4.2,5.3,2.25,graphite); color(silver) translate([2.9,-3.3,pcb_t+2.28]) linear_extrude(0.035) text("AMS1117 3.3V",size=0.72,halign="center",valign="center"); }
module capacitors(){ capacitor(-5.7,-5.0); smd(-8.6,-5.0,1.5,2.0,0.8,beige); smd(7.5,-1.2,1.1,1.8,0.7,beige); }
module resistors(){ for(p=[[-7.4,-9.1],[-5.1,-9.1],[-7.4,-11.2],[-4.8,-11.2],[5.7,-8.2],[7.7,-8.2],[5.7,-11.0],[7.7,-11.0]]) resistor(p[0],p[1]); }
module power_circuit(){ ams1117_regulator(); capacitors(); resistors(); color(green) translate([-8.3,-13.2,pcb_t+0.35]) cylinder(r=0.48,h=0.35); color(blue_led) translate([8.3,-13.2,pcb_t+0.35]) cylinder(r=0.42,h=0.35); }
module cp2102_chip(){ smd(0,-16.8,7.4,7.0,1.45,graphite); color(ivory) translate([0,-16.8,pcb_t+1.48]) rotate([0,0,90]) linear_extrude(0.035) text("SILABS CP2102",size=1.05,halign="center",valign="center",font="Liberation Sans:style=Bold");
 color(silver) for(s=[-1,1],i=[0:7]) translate([s*4.0,-19.6+i*0.8,pcb_t+0.22]) rounded_box(0.65,0.42,0.35,0.1);
}
module tactile_button(x,y,label){ color(silver) translate([x,y,pcb_t+0.45]) rounded_box(3.2,3.2,0.9,0.45); color(graphite) translate([x,y,pcb_t+1.2]) cylinder(r=0.95,h=1.25); color(black) translate([x,y,pcb_t+1.82]) sphere(r=0.72); color(ivory) translate([x,y+2.5,pcb_t+0.08]) linear_extrude(0.03) text(label,size=1.0,halign="center",valign="center"); }
module en_button(){ tactile_button(-7.3,-24.0,"EN"); }
module io0_button(){ tactile_button(7.3,-24.0,"IO0"); }
module buttons(){ en_button(); io0_button(); }
module usb_c_connector(){
 // Hollow shell assembled from rounded side walls and a dark recessed socket.
 color(silver) translate([0,usb_y,0.8]) difference(){ rounded_box(9.4,7.2,3.2,1.25); translate([0,-0.15,0.15]) rounded_box(7.2,6.8,2.15,0.9); }
 color(black) translate([0,usb_y-0.55,0.82]) rounded_box(7.0,0.5,1.65,0.48);
 if(show_usb_internals){ color([0.72,0.67,0.52]) translate([0,usb_y-0.32,0.75]) rounded_box(4.8,0.7,0.48,0.18); color(gold) for(x=[-2.0:0.8:2.0]) translate([x,usb_y-0.66,0.82]) cube([0.22,0.32,0.08],center=true); }
 color(bright_silver) for(x=[-3.7,3.7]) translate([x,usb_y+2.8,0.65]) rounded_box(1.0,1.8,1.3,0.25);
}
module front_silkscreen(){ color(ivory) { for(s=[-1,1]) translate([s*10.1,0,pcb_t+0.035]) rotate([0,0,90]) linear_extrude(0.025) text("ESP32",size=1.1,halign="center",valign="center"); } }
module complete_board(){
 pcb_body(); pcb_edges(); if(show_copper){copper_traces_front();copper_traces_back();} pcb_vias(); solder_pads();
 if(show_gpio_contacts) gpio_contacts();
 if(show_front_components){ esp32_antenna(); esp32_rf_shield(); esp32_castellations(); power_circuit(); cp2102_chip(); buttons(); usb_c_connector(); front_silkscreen(); }
 if(show_gpio_labels) gpio_labels_back(); rear_silkscreen();
}

if(part=="all") complete_board();
if(part=="pcb") { pcb_body(); pcb_edges(); pcb_vias(); }
if(part=="rf") { esp32_antenna(); esp32_rf_shield(); esp32_castellations(); }
if(part=="usb") usb_c_connector();
if(part=="gpio") gpio_contacts();
if(part=="power") power_circuit();
if(part=="cp2102") cp2102_chip();
if(part=="buttons") buttons();
